Youth.Climate — Static site
===========================

Files:
- index.html
- styles.css
- scripts.js
- members1.png
- members2.png
- favicon.png

How to preview locally:
1. Open index.html in your browser directly (double-click). For best results serve via a simple HTTP server:
   - Python 3: `python -m http.server 8000` then open http://localhost:8000

How to publish for free:
- GitHub Pages:
  1. Create a new GitHub repo (e.g. youth.climate).
  2. Push these files to the repo (main branch).
  3. In repo Settings -> Pages, choose the branch (main) and root folder to publish.
  4. GitHub will provide a URL like https://<your-username>.github.io/<repo>/ .
- Netlify:
  1. Drag the site folder to Netlify Drop (or connect repo).
  2. Netlify will publish the static site and give a URL.
- Custom domain:
  - To use youth.climate as a real domain you'll need to purchase/register it and point DNS to your host (Netlify or GitHub Pages instructions available in their docs).

Notes:
- This is a static demo. To collect form submissions or host a contact form you'll need a backend or a service (Formspree, Netlify Forms, etc.)
